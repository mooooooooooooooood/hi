package DSA.tut9;

import java.util.Arrays;

public class ArrayTree {
    private static final int maxSize = 10;
    private int n; // Current number
    private String[] l;
    private int[] p;

    public ArrayTree() {
        n = 0;
        l = new String[maxSize];
        p = new int[maxSize];
        Arrays.fill(p, -1);
    }

    public boolean isFull() {
        return n == maxSize;
    }

    public boolean isEmpty() {
        return n == 0;
    }

    public void addNode(String label, int parent) {
        if (isFull()) {
            System.out.println("Tree is full, cannot add node.");
            return;
        }
        if (parent < -1 || parent >= maxSize || (parent >= 0 && l[parent] == null)) {
            System.out.println("Invalid parent node index.");
            return;
        }

        for (int i = 0; i < maxSize; i++) {
            if (l[i] == null) {
                l[i] = label;
                p[i] = parent;
                n++;
                return;
            }
        }
    }


    public int getParent(int node) {
        if (node < 0 || node >= maxSize) {
            System.out.println("Invalid node index.");
            return -1;
        }
        return p[node];
    }

    public String getNodeLabel(int node) {
        if (node < 0 || node >= maxSize) {
            System.out.println("Invalid node index.");
            return null;
        }
        return l[node];
    }

    public void setNodeLabel(int node, String label) {
        if (node < 0 || node >= maxSize) {
            System.out.println("Invalid node index.");
            return;
        }
        l[node] = label;
    }

    public int leftMostChild(int node) {
        if (node < 0 || node >= maxSize) {
            System.out.println("Invalid node index.");
            return -1;
        }
        for (int i = 0; i < maxSize; i++) {
            if (p[i] == node) {
                return i;
            }
        }
        return -1; // No children
    }

    public int nearestRightSibling(int node) {
        if (node < 0 || node >= maxSize) {
            System.out.println("Invalid node index.");
            return -1;
        }
        int parent = p[node];
        for (int i = node + 1; i < maxSize; i++) {
            if (p[i] == parent) {
                return i;
            }
        }
        return -1; // No right sibling
    }

    public void printTree() {
        System.out.println("Tree Structure:");
        for (int i = 0; i < maxSize; i++) {
            if (l[i] != null) {
                System.out.println("Node " + i + " (" + l[i] + ") -> Parent: " + p[i]);
            }
        }
    }

    public int getDegree(int node) {
        int degree = 0;
        for (int i = 0; i < maxSize; i++) {
            if (p[i] == node) {
                degree++;
            }
        }
        return degree;
    }

    public boolean isLeaf(int node) {
        return getDegree(node) == 0;
    }

    public int countLeaves() {
        int count = 0;
        for (int i = 0; i < maxSize; i++) {
            if (l[i] != null && isLeaf(i)) {
                count++;
            }
        }
        return count;
    }

    public int getLevel(int node) {
        int level = 0;
        while (node != -1) {
            node = p[node];
            level++;
        }
        return level - 1; // Subtract 1 as the root level is considered 0
    }

    public int getDepth() {
        int maxDepth = 0;
        for (int i = 0; i < maxSize; i++) {
            if (l[i] != null && isLeaf(i)) {
                int depth = getLevel(i);
                if (depth > maxDepth) {
                    maxDepth = depth;
                }
            }
        }
        return maxDepth;
    }

    public int search(String label) {
        for (int i = 0; i < maxSize; i++) {
            if (l[i] != null && l[i].equals(label)) {
                return i;
            }
        }
        return -1;
    }
}
