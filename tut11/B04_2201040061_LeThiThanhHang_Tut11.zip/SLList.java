package DSA.tut11;

public class SLList {
    private SLNode head;
    public SLList() {
        this.head = null;
    }

    public SLNode getHead() {
        return this.head;
    }

    public void setHead(SLNode head) {
        this.head = head;
    }

    public boolean isEmpty() {
        return head == null;
    }

    private SLNode traversing(int pos)
    {
        SLNode current = head;
        for (int i = 0 ; i < pos; i++) {
            current = current.getNext();
        }
        return current;
    }

    public void add(SLNode newNode)
    {
        newNode.setNext(head);
        head = newNode;
    }

    public SLNode get(int pos) {
        if (isEmpty() || pos < 0) {
            return null;
        }
        SLNode current = traversing(pos);
        return current;
    }

    public int getLength() {
        int length = 0;
        SLNode current = head;
        while (current != null) {
            length++;
            current = current.getNext();
        }
        return length;
    }
}
