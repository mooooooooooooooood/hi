package DSA.tut11;

import java.util.LinkedList;
import java.util.Queue;

public class GraphBFS {
    private static int n = 7;
    private static int[][] a = {
            {0,1,0,0,1,0,0},
            {1,0,1,0,0,0,1},
            {0,1,0,0,0,1,0},
            {0,0,0,0,1,1,0},
            {1,0,0,1,0,1,0},
            {0,0,1,1,1,0,0},
            {0,1,0,0,0,0,0}
    };
    private static GVertex[] v;

    /**
     * Constructor for objects of class GraphBFS
     */
    public GraphBFS() {
    }

    public static void BFS(int s) {
        boolean[] visited = new boolean[n];
        Queue<Integer> queue = new LinkedList<>();

        visited[s] = true;
        queue.add(s);

        while (!queue.isEmpty()) {
            int current = queue.poll();
            System.out.print(v[current].getLabel() + " ");

            for (int i = 0; i < n; i++) {
                if (a[current][i] == 1 && !visited[i]) {
                    visited[i] = true;
                    queue.add(i);
                }
            }
        }
        System.out.println();
    }

    public static void main(String[]args) {
        v = new GVertex[n];     //Create an empty list of n vertices
        // Initialize vertex's label
        v[0]=new GVertex('A');
        v[1]=new GVertex('B');
        v[2]=new GVertex('C');
        v[3]=new GVertex('D');
        v[4]=new GVertex('E');
        v[5]=new GVertex('F');
        v[6]=new GVertex('G');

        System.out.println("BFS traversal from vertex v[0]");
        BFS(0);
        System.out.println("BFS traversal from vertex v[6]");
        BFS(6);
    }
}
