package DSA.tut11;

public class ArrayQueue {
    private int[] items;
    private static final int maxSize = 10000;
    private int front;
    private int rear;

    /**
     * Constructor for objects of class ArrayQueue.
     * This constructor creates an empty queue.
     */
    public ArrayQueue() {
        items = new int[maxSize];
        front = 0;
        rear = -1;
    }

    /**
     * This operation returns true if the queue is empty, otherwise it returns false
     */
    public boolean isEmpty() {
        return rear < front;
    }

    /**
     * This operation returns true if the queue is full, otherwise it returns false
     */
    public boolean isFull() {
        return rear == maxSize - 1;
    }

    /**
     * This operation adds a newItem to the queue.
     */
    public void enqueue(int newItem) {
        if (isFull()) {
            System.out.println("Queue is full. Cannot enqueue.");
            return;
        }
        items[++rear] = newItem;
    }

    /**
     * This operation returns the item at the front position of the queue and deletes this item.
     */
    public int dequeue() {
        if (isEmpty()) {
            System.out.println("Queue is empty. Cannot dequeue.");
            return -1;
        }
        return items[front++];
    }

    /**
     * This operation returns an item at the front position of the queue. This item will not be deleted.
     */
    public int peek() {
        if (isEmpty()) {
            System.out.println("Queue is empty. Cannot peek.");
            return -1;
        }
        return items[front];
    }
}
