package DSA.tut6;

public class SLList {
    private SLNode head;

    public SLList() {
        this.head = null;
    }

    public void add(SLNode n) {
        n.setNext(head);
        head = n;
    }

    public void remove(int pos) {
        if (pos <= 0 || head == null) {
            return;
        }

        if (pos == 1) {
            head = head.getNext();
            return;
        }

        SLNode current = head;
        for (int i = 1; i < pos - 1 && current.getNext() != null; i++) {
            current = current.getNext();
        }

        if (current.getNext() != null) {
            current.setNext(current.getNext().getNext());
        }
    }

    public void addAt(int pos, SLNode n) {
        if (pos <= 0) {
            return;
        }

        if (pos == 1) {
            n.setNext(head);
            head = n;
            return;
        }

        SLNode current = head;
        for (int i = 1; i < pos - 1 && current != null; i++) {
            current = current.getNext();
        }

        if (current != null) {
            n.setNext(current.getNext());
            current.setNext(n);
        }
    }

    public boolean isEmpty() {
        return head == null;
    }

    //Current length
    public int length() {
        int count = 0;
        SLNode current = head;

        while (current != null) {
            count++;
            current = current.getNext();
        }

        return count;
    }

    public void print() {
        SLNode current = head;
        while (current != null) {
            current.print();
            current = current.getNext();
        }
    }

    // Search for a string data
    public int search(String data) {
        SLNode current = head;
        int pos = 1;

        while (current != null) {
            if (current.getData().equals(data)) {
                return pos;
            }
            current = current.getNext();
            pos++;
        }

        return -1; // Not found
    }
}