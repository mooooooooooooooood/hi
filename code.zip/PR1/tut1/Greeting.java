package PR1.tut1;

public class Greeting {
    public static void main(String[] args){
        String myName = "Hang";
        String mob = "may";
        int yob = 2004;
        String intro = "I'm from Hanoi. I went to school,etc";
        System.out.print("Hi, my name is "+ myName + ".");
        System.out.print("I was born in "+mob+","+ yob+".");
        System.out.println(intro);
    }
}
