package PR1.tut1;

public class PrintMyAge {
    public static void main(String[] args) {
        System.out.println("I was born in 2004. This year is 2023.");
        System.out.println("Therefore, my age is: ");
        System.out.print("19");
    }
}
