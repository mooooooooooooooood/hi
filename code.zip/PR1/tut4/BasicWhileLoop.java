package PR1.tut4;

public class BasicWhileLoop {
    public static void maid (String[] args) {
        int i = 1;
        while (i <= 10) {
            i++;
            System.out.println(i);
        }
    }
}