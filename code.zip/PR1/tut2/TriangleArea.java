package PR1.tut2;

public class TriangleArea {
    public static void main (String[] args) {
        double h = 1.5;
        int b = 3;
        double area = (h*b)/2;
        System.out.print("The triangle's base is "+ b +" (cm)");
        System.out.println(" and height is "+ h +" (cm)");
        System.out.println("Its area (cm2) is:" );
        System.out.println(area);
    }
}
