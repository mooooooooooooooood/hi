package PR2.tut07.library;

public enum Format {
    Hardcover, Paperback, Audiobook, Ebook, Newspaper, Magazine, Journal
}
