package PR2.tut07.library;

public enum BookStatus {
    Available, Reserved, Loaned, Lost
}
