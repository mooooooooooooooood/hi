package PR2.tut07.library;

public enum AccountStatus {
    Active,
    Disabled,
    Restricted,
    Blacklisted,
    Deleted
}
