package PR2.tut12.greetings;

public enum Color {
    Blue, Red, Orange, Purple, Yellow
}
