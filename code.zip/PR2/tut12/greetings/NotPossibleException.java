package PR2.tut12.greetings;

public class NotPossibleException extends RuntimeException {
    public NotPossibleException(String message) {
        super(message);
    }
}