package PR2.tut6;

public enum Colors {
    White,
    Black,
    Red,
    Pink,
    Orange,
    Yellow,
    Purple,
    Green,
    Blue,
    Brown
}
