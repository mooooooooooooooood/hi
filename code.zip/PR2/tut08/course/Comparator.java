package PR2.tut08.course;

public interface Comparator {
    public int compare (Course c1, Course c2) throws Exception;
}
