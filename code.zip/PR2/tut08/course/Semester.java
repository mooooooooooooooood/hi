package PR2.tut08.course;

public enum Semester {
    Fall, Spring
}
