package PR2.tut08.course;

public enum Department {
    FIT, English, Chinese, Italia, Korean
}
