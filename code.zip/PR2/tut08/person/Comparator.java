package PR2.tut08.person;

public interface Comparator{
    public int compare(Person p1, Person p2) throws Exception;
    public double compare (Student s1, Student s2) throws Exception;
}
