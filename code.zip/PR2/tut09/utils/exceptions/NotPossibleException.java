package PR2.tut09.utils.exceptions;

public class NotPossibleException extends RuntimeException {
    public NotPossibleException(String message) {
        super(message);
    }
}
