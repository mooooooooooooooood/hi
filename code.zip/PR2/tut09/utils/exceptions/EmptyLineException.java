package PR2.tut09.utils.exceptions;
public class EmptyLineException extends Exception {
    public EmptyLineException(String message) {
        super(message);
    }
}
