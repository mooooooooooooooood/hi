package PR2.tut09.utils.exceptions;

public class WordLengthException extends Exception {
    public WordLengthException(String message) {
        super(message);
    }
}