package utils.collections;

import java.util.Vector;

/**
 * @overview
 *  An interface representing all kinds of collection classes, including sets, lists, queues, sorts.
 */
public interface Collection<E> {
    public Vector<E> getElements();
}