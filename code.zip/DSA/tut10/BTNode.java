package DSA.tut10;

public class BTNode {
    public String label;
    public BTNode(String label) {
        this.label = label;
    }

    public String getLabel() {
        return this.label;
    }

    public void setLabel(String label) {
        this.label = label;
    }
}
