package DSA.tut8;

public class StackNode {
    char data;
    StackNode next;

    public StackNode(char data) {
        this.data = data;
        this.next = null;
    }
}